package com.sap.cloud.s4hana.examples.addressmgr;

import org.junit.Test;

import static org.junit.Assert.*;

public class UnitTest {
    @Test
    public void test() {
        assertTrue(true);
    }
}

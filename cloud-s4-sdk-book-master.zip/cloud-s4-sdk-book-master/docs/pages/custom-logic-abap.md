---
layout: default
title: ABAP Source Code for Custom Logic
---
# ABAP Source Code for Custom Logic
You can find the ABAP source code of the examples for custom business logic (Chapter 19) at the following places:
* Chapter 19.8: [Custom logic for business partner validation](https://github.com/SAP/cloud-s4-sdk-book/blob/master/docs/assets/abap/19_1_bp_custom_validation_logic.abap)
* Chapter 19.9: [Custom logic for calling an external service](https://github.com/SAP/cloud-s4-sdk-book/blob/master/docs/assets/abap/19_2_cbl_bpsocialmediaaccounts_check_account.abap)
